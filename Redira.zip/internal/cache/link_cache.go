package cache

import (
	"context"
	"time"
)

const LinkTTL = 24 * time.Hour

func (c *Cache) GetOriginalURL(ctx context.Context, shortCode string) (string, error) {
	return c.Get(ctx, LinkKey(shortCode))
}

func (c *Cache) StoreOriginalURL(ctx context.Context, shortCode, url string) error {
	return c.Set(ctx, LinkKey(shortCode), url, LinkTTL)
}
