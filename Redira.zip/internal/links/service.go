package links

import (
	"context"

	"github.com/abass-codes/redira/internal/cache"
	db "github.com/abass-codes/redira/internal/database/db"
	"github.com/jackc/pgx/v5/pgtype"
)

type Service struct {
	repository *Repository
	cache      *cache.Cache
}

func NewService(repository *Repository, cache *cache.Cache) *Service {
	return &Service{
		repository: repository,
		cache:      cache,
	}
}

func (s *Service) Create(ctx context.Context, originalURL string) (*db.Link, error) {
	shortCode, err := GenerateUniqueCode(ctx)
	if err != nil {
		return nil, err
	}

	link, err := s.repository.Create(ctx, originalURL, shortCode)
	if err != nil {
		return nil, err
	}

	_ = s.cache.StoreOriginalURL(ctx, shortCode, originalURL)

	return link, nil
}

func (s *Service) Redirect(ctx context.Context, shortCode string) (*db.Link, error) {

	// Redis Cache
	if originalURL, err := s.cache.GetOriginalURL(ctx, shortCode); err == nil {
		return &db.Link{
			OriginalUrl: originalURL,
			ShortCode:   shortCode,
		}, nil
	}

	// PostgreSQL
	link, err := s.repository.GetByShortCode(ctx, shortCode)
	if err != nil {
		return nil, err
	}

	_ = s.cache.StoreOriginalURL(ctx, shortCode, link.OriginalUrl)

	_ = s.repository.IncrementClicks(ctx, link.ID)

	return link, nil
}

func (s *Service) IncrementClicks(ctx context.Context, id pgtype.UUID) error {
	return s.repository.IncrementClicks(ctx, id)
}
